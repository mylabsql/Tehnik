<?php
class Tech_event extends msDB {
  private $grid; 
  
  public function __construct(){
    $this->connect(); 
    $this->grid = new Grid; 
    $this->grid->setTable("tech_event"); 
    $this->grid->setJoin('inner join event on event.id=tech_event.event_id');
    $this->grid->addField(
                array(
                    'field' => 'tech_event.id',
                    'name'  => 'id',
                    'primary'=> true,
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false)
                    )      
    ));
    $this->grid->addField(
            array(
                'field' => 'event.event',
                'name'  => 'event_id',
                'meta' => array(
                  'st' => array('type' => 'string'), 
                  'cm' => array('header' => 'Event','width' => 200,'sortable' => true),
                  'filter' => array('type' => 'string')
                )
            ));  
    $this->grid->addField(
            array(
                'field' => 'rev_no',
                'name'  => 'rev_no',
                'meta' => array(
                  'st' => array('type' => 'string'), 
                  'cm' => array('header' => 'Rev no','width' => 50,'sortable' => true),
                  'filter' => array('type' => 'string')
                )
            ));       
            $this->grid->addField(
            array(
                'field' => 'tech_event.keterangan',
                'name'  => 'keterangan',
                'meta' => array(
                  'st' => array('type' => 'string'), 
                  'cm' => array('header' => 'Keterangan','width' => 400,'sortable' => true),
                  'filter' => array('type' => 'string')
                )
            ));             
  }
  
  public function getdokumen($request){
     $this->grid->setManualFilter(" and status = '1'"); 
    return $this->grid->doRead($request); 
  }
  
  public function edit($id,$request){
     $grid_edit = new Grid; 
    $grid_edit->setTable("tech_event"); 
    $grid_edit->addField(
                array(
                    'field' => 'tech_event.id',
                    'name'  => 'id',
                    'primary'=> true,
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false)
                    )      
    ));
    $grid_edit->addField(
            array(
                'field' => 'event_id',
                'name'  => 'event_id',
                'meta' => array(
                  'st' => array('type' => 'string'), 
                  'cm' => array('header' => 'Event','width' => 200,'sortable' => true),
                  'filter' => array('type' => 'string')
                )
            ));  
            $grid_edit->addField(
            array(
                'field' => 'rev_no',
                'name'  => 'rev_no',
                'meta' => array(
                  'st' => array('type' => 'string'), 
                  'cm' => array('header' => 'Rev no','width' => 60,'sortable' => true),
                  'filter' => array('type' => 'string')
                )
            ));       
            $grid_edit->addField(
            array(
                'field' => 'keterangan',
                'name'  => 'keterangan',
                'meta' => array(
                  'st' => array('type' => 'string'), 
                  'cm' => array('header' => 'Keterangan','width' => 400,'sortable' => true),
                  'filter' => array('type' => 'string')
                )
            ));       
	 $grid_edit->loadSingle = true;
     $grid_edit->setManualFilter(" and tech_event.id = $id"); 
     return $grid_edit->doRead($request); 
  }
  public function getspek($tech_event_id, $request){
    $grid_spek = new Grid; 
    $grid_spek->setTable('tech_event_list');
    $grid_spek->setJoin('inner join equipment_name on equipment_name.id=tech_event_list.eqname_id');
    $grid_spek->setManualFilter(" and tech_event_id = $tech_event_id");
    $grid_spek->addField(
                  array(
                    'field' => 'tech_event_list.id',
                    'name' => 'id',
                    'primary' => true,
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false)
                    )                      
                  )
                );

    $grid_spek->addField(
                  array(
                    'field' => 'bagian',
                    'name' => 'bagian',
                    'meta' => array(
                      'st' => array('type' => 'string'), 
                      'cm' => array('header' => 'Group', 'sortable' => true)
                    )
                  )
                );
        $grid_spek->addField(
                  array(
                    'field' => 'nama_equip',
                    'name' => 'nama_equip',
                    'meta' => array(
                      'st' => array('type' => 'string'), 
                      'cm' => array('header' => 'Nama equipment', 'sortable' => true)
                    )
                  )
                );
                $grid_spek->addField(
                  array(
                    'field' => 'jumlah',
                    'name' => 'jumlah',
                    'meta' => array(
                      'st' => array('type' => 'string'), 
                      'cm' => array('header' => 'Jumlah', 'sortable' => true)
                    )
                  )
                );
    $grid_spek->addField(
                  array(
                    'field' => 'tech_event_list.keterangan',
                    'name' => 'keterangan',
                    'meta' => array(
                      'st' => array('type' => 'string'), 
                      'cm' => array('header' => 'Keterangan', 'width' => 400, 'sortable' => true)
                    )                  
                  )
                );   

  return $grid_spek->doRead($request);                 
                    
  }    
  
  public function create($post){
   
    /** start build query **/
    $this->db->BeginTrans(); 
    /** parent query **/     
    $str ="INSERT INTO event_rec(event_id, tanggal, lokasi, jenis)VALUES('%s','%s','%s','%s')"; 
    $query= sprintf($str,mysql_real_escape_string($post['event_id']),
						 mysql_real_escape_string($post['tanggal']),
                         mysql_real_escape_string($post['lokasi']),
						 mysql_real_escape_string($post['jenis'])); 
                         
   $this->setSQL($query);   
    /** child query **/
   $ok = $this->executeSQL(); 
   if ($ok)
    if ($post['detail'] != '[]'){
      $sql = array(); 
      $rec_id = $this->getLastID(); 
      $detail = json_decode(stripslashes($post['detail'])); 
      foreach ($detail as $row){
        $col = array(); 
        $val = array(); 
        $col[]= 'rec_id'; 
        $val[]= $rec_id; 
        foreach ($row as $head=>$value){
          $col[] =  $head; 
          $val[] = "'". mysql_real_escape_string($value) ."'";     
        }
		$uid = $_SESSION['userid'];
        $sql[] = sprintf("INSERT INTO activity (%s,user_id) VALUES (%s,'$uid')", implode(',',$col),implode(',',$val));
      }    
      
      foreach ($sql as $str){
        if ($ok){
          $this->setSQL($str);
          $ok = $this->executeSQL(); 
        }
      }
    }
    if ($ok)
      $this->db->CommitTrans(); 
    else
      $this->db->RollbackTrans(); 
    /** end build query **/

    $result = new stdClass(); 
    $result->success = ($ok)?true:false; 
    $result->message = $this->db->ErrorMsg(); 
    
    return json_encode($result); 
  }
  
  public function update($post){
   
    /** start build query **/
    $this->db->BeginTrans(); 
    /** parent query **/    
    $str ="UPDATE event_rec SET tanggal='%s', event_id='%s', lokasi='%s', jenis='%s' WHERE id = '%s'"; 
    $query= sprintf($str,mysql_real_escape_string($post['tanggal']),
						 mysql_real_escape_string($post['event_id']),
                         mysql_real_escape_string($post['lokasi']), 
                         mysql_real_escape_string($post['jenis']), 
                         mysql_real_escape_string($post['id']));  
                                               
   $this->setSQL($query);   
   $ok = $this->executeSQL();
   /** child query update **/ 
   if ($ok)
    if ($post['detail'] != '[]'){
      $sql = array(); 
      $detail = json_decode(stripslashes($post['detail'])); 
      foreach ($detail as $row){
        if (isset($row->activity_id)){
            $fields = array();
            $activity_id = 0; 
            foreach ($row as $head=>$value){
              if ($head != 'activity_id'){
                $fields[] = $head . '='. "'".mysql_real_escape_string($value)."'";
              }else{
                $activity_id = $value; 
              }
    
            }
		   //$uid = $_SESSION['userid'];
           $query = "UPDATE activity SET %s WHERE activity_id=%s";
           $query = sprintf($query,implode(',',$fields),$activity_id); 
           $sql[] = $query;           
        }else{
          $col = array(); 
          $val = array(); 
          $col[]= 'rec_id'; 
          $val[]= $post['id']; 
          foreach ($row as $head=>$value){
            $col[] =  $head; 
            $val[] = "'". mysql_real_escape_string($value) ."'";     
          }
		  $uid = $_SESSION['userid'];
          $sql[] = sprintf("INSERT INTO activity (%s,user_id) VALUES (%s,'$uid')", implode(',',$col),implode(',',$val)); 
        }

      }    
      
      foreach ($sql as $str){
        if ($ok){
          $this->setSQL($str);
          $ok = $this->executeSQL(); 
        }
      }
    }
    
    if ($post['remove'])
      if ($ok){
        $sql = "DELETE FROM activity WHERE activity_id IN (%s)"; 
        $query = sprintf($sql,$post['remove']); 
        $this->setSQL($query);
        $ok = $this->executeSQL(); 
      }
      
    if ($ok)
      $this->db->CommitTrans(); 
    else
      $this->db->RollbackTrans(); 
    /** end build query **/

    $result = new stdClass(); 
    $result->success = ($ok)?true:false; 
    $result->message = $this->db->ErrorMsg(); 
    
    return json_encode($result); 
  }
  
  
  public function destroy($data){
    $this->db->BeginTrans();     
    $sql = "DELETE FROM activity WHERE rec_id in(%s)"; 
    $query = sprintf($sql,$data);    
    $this->setSQL($query);
    $ok = $this->executeSQL();
    if ($ok){
      $sql = "DELETE FROM event_rec WHERE id in (%s)"; 
      $query = sprintf($sql,$data);
      $this->setSQL($query);
      $ok = $this->executeSQL();
    }
        
    if ($ok)
      $this->db->CommitTrans(); 
    else
      $this->db->RollbackTrans(); 
          
    $result = new stdClass(); 
    $result->success = ($this->db->ErrorMsg()!='')?false:true; 
    $result->message = $this->db->ErrorMsg(); 
    
    return json_encode($result); 
  }
 

  public function getcmbte_event($request){

		$sql = "select count(*) from event"; 
		$data = array();
		$rsTotal = mysql_query($sql); 
      while($rows = mysql_fetch_array($rsTotal))
{      $total = $rows[0];}
		$data = Array();
		$sql = "select id, event from event";
		$rsData = mysql_query($sql); 
if(mysql_num_rows($rsData)>0){
      while($rows = mysql_fetch_array($rsData))
      			{$data[]=array(
'id' => $rows["id"],
'event' => $rows["event"]
);}
    } else {
      $data = array("empty");      // failure
    }


		

		$result = new stdClass(); 
		$result->success = true; 
		$result->total = $total; 
		$result->data = $data; 
		
		return json_encode($result); 

}

public function getcmbte_eqname_id($request){

		$sql = "select count(*) from equipment_name"; 
		$data = array();
		$rsTotal = mysql_query($sql); 
      while($rows = mysql_fetch_array($rsTotal))
{      $total = $rows[0];}
		$data = Array();
		$sql = "select id, concat(nama_equip, ' -- [', bagian,']') as bagian from equipment_name";
		$rsData = mysql_query($sql); 
if(mysql_num_rows($rsData)>0){
      while($rows = mysql_fetch_array($rsData))
      			{$data[]=array(
'id' => $rows["id"],
'bagian' => $rows["bagian"]
);}
    } else {
      $data = array("empty");      // failure
    }


		

		$result = new stdClass(); 
		$result->success = true; 
		$result->total = $total; 
		$result->data = $data; 
		
		return json_encode($result); 

}


}
?>