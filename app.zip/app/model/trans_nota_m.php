<?php
class Trans_nota01 extends msDB { //class Hwd dengan extend/parameter msDB//
    var $grid; //variabel $grid

    function  __construct() { //fungsi construc//
        $this->connect();
        $this->grid = new Grid;
        $this->grid->setTable('trans_nota');
        $this->grid->addField(
                array(
                     'field' => 'id',
                    'name'  => 'id',
                    'primary'=> true,
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false, 'menuDisabled' => true)
                    )
                ));
		$this->grid->addField(
                array(
                    'field' => 'tanggal',
                    'name'  => 'tanggal',
                    'meta' => array(
                      'st' => array('type' => 'date', 'allowBlank' => false), 
                      'cm' => array('header' => 'Tanggal','sortable' => true, 'renderer' => "Ext.util.Format.date(val,'d/m/Y')")
			)
                ));	
		$this->grid->addField(
                array(
                    'field' => 'trans_id',
                    'name'  => 'trans_id',
                    'meta' => array(
                      'st' => array('type' => 'int', 'allowBlank' => true), 
                      'cm' => array('header' => 'trans_id','sortable' => true),
                      'filter' => array('type' => 'int')
			)
                ));
		$this->grid->addField(
                array(
                    'field' => 'nota',
                    'name'  => 'nota',
                    'meta' => array(
                      'st' => array('type' => 'string', 'allowBlank' => false), 
                      'cm' => array('header' => 'Nomer transaksi','width' => 125,'sortable' => true),
                      'filter' => array('type' => 'string')
			)
                ));
		$this->grid->addField(
                array(
                     'field' => 'admin',
                    'name'  => 'admin',
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false, 'menuDisabled' => true)
                    )
                ));
		$this->grid->addField(
		array(
                    'field' => 'keterangan',
                    'name' => 'keterangan',
                    'meta' => array(
                      'st' => array('type' => 'string'), 
                      'cm' => array('header' => 'Keterangan', 'width' => 500, 'sortable' => true)
                    )                  
                  )
                );  
    }

    function create($request){ //fungsi create + return data//
         $data = array(
          'trans_id' => $request['trans_id'],
	  'tanggal' => $request['tanggal'],
          'nota' => $request['nota'],
          'keterangan' => $request['keterangan'],
	  'admin' => $request['usr_id']
        );                
        return $this->grid->doCreate(json_encode($data));
}

    function edit($id,$request){ //fungsi edit//
       $this->grid->loadSingle = true;
       $this->grid->setManualFilter(" and id = $id"); 
       return $this->grid->doRead($request); 
    }
    
    function read($request){ // fungsi memabaca + return data //
        $trxnota_edit = new Grid;
        $trxnota_edit->setTable('trans_nota');
        $trxnota_edit->setJoin('inner join trans on trans.id=trans_nota.trans_id');	
        $trxnota_edit->addField(
                array(
                     'field' => 'trans_nota.id',
                    'name'  => 'id',
                    'primary'=> true,
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false, 'menuDisabled' => true)
                    )
                ));
		$trxnota_edit->addField(
                array(
                    'field' => 'tanggal',
                    'name'  => 'tanggal',
                    'meta' => array(
                      'st' => array('type' => 'date', 'allowBlank' => false), 
                      'cm' => array('header' => 'Tanggal','sortable' => true,'renderer' => "Ext.util.Format.date(val,'d/m/Y')")
			)
                ));
		$trxnota_edit->addField(
                array(
                    'field' => 'trans.nama_trans',
                    'name'  => 'nama_trans',
                    'meta' => array(
                      'st' => array('type' => 'string', 'allowBlank' => true), 
                      'cm' => array('header' => 'Nama transaksi','width' => 150,'sortable' => true),
                      'filter' => array('type' => 'string')
			)
                ));		
		$trxnota_edit->addField(
                array(
                    'field' => 'nota',
                    'name'  => 'nota',
                    'meta' => array(
                      'st' => array('type' => 'string', 'allowBlank' => false), 
                      'cm' => array('header' => 'Nomer transaksi','width' => 125,'sortable' => true),
                      'filter' => array('type' => 'string')
			)
                ));
		$trxnota_edit->addField(
                array(
                     'field' => 'trans_nota.admin',
                    'name'  => 'admin',
                    'meta' => array(
                      'st' => array('type' => 'int'),
                      'cm' => array('hidden' => true, 'hideable' => false, 'menuDisabled' => true)
                    )
                ));
		$trxnota_edit->addField(
		array(
                    'field' => 'trans_nota.keterangan',
                    'name' => 'keterangan',
                    'meta' => array(
                      'st' => array('type' => 'string'), 
                      'cm' => array('header' => 'Keterangan', 'width' => 500, 'sortable' => true)
                    )                  
                  )
                );  
       return $trxnota_edit->doRead($request); 

    }
    function update($request){  //fungsi update + return data
        $data = array(
          'id' => $request['id'],
	  'tanggal' => $request['tanggal'],
          'trans_id' => $request['trans_id'],
          'nota' => $request['nota'],
          'keterangan' => $request['keterangan'],
	  'admin' => $request['usr_id']
	  );
        return $this->grid->doUpdate(json_encode($data));
    }
    
    function doReport($request){
      return $this->grid->dosql($request); 
    }

    function destroy($request){
        return $this->grid->doDestroy($request);
    }
    public function getcmbtrans01($request){

		$sql = "select count(*) from trans"; 
		$data = array();
		$rsTotal = mysql_query($sql); 
      while($rows = mysql_fetch_array($rsTotal))
{      $total = $rows[0];}
		$data = Array();
		$sql = "select id, nama_trans from trans";
		$rsData = mysql_query($sql); 
if(mysql_num_rows($rsData)>0){
      while($rows = mysql_fetch_array($rsData))
      			{$data[]=array(
'id' => $rows["id"],
'nama_trans' => $rows["nama_trans"]
);}
    } else {
      $data = array("empty");      // failure
    }


		

		$result = new stdClass(); 
		$result->success = true; 
		$result->total = $total; 
		$result->data = $data; 
		
		return json_encode($result); 

}		//image path

  
}
?>
