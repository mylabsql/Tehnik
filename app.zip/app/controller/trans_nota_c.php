<?php
    $action = $_REQUEST['action'];
    $handler->loadModel('trans_nota_m');
    $trans_nota01 = new Trans_nota01;

    switch ($action){
        case 'read':
            echo $trans_nota01->read($_POST);
            break;
        case 'getcmbtrans01':
        	echo $trans_nota01->getcmbtrans01($_REQUEST); 
        	break;  
        case 'create':
            echo $trans_nota01->create($_POST);
            break;
        case 'update':
            echo $trans_nota01->update($_POST);
            break;
        case 'destroy':
            echo $trans_nota01->destroy($_POST['data']);
            break;            
        case 'edit':
          echo $trans_nota01->edit($_POST['id'],$_POST); 
          break; 
    }
?>