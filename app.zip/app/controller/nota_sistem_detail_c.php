<?php
    $action = $_REQUEST['action'];
    $handler->loadModel('nota_sistem_detail_m');
    $sistemdetailnota = new Sistemdetailnota; 

    switch ($action){
	case 'getcmbnota06':
		$result = $sistemdetailnota->getcmbnota06($_POST['start'], $_POST['limit'], $_REQUEST); 
		echo $result;  
			break;
        case 'outlistnota06':
            echo $sistemdetailnota->outlistnota06($_POST['cmbNota06'],/*$_POST['usr_id'],*/$_POST);
            break;
	case 'inlistnota06':
            echo $sistemdetailnota->inlistnota06($_POST['cmbNota06'],/*$_POST['usr_id'],*/$_POST);
            break;
        case 'cekSN06':
        	echo $sistemdetailnota->cekSN06($_POST['textSN06'],/*$_POST['usr_id'],*/$_REQUEST); 
        	break;
        case 'statusSN06':
	        echo $sistemdetailnota->statusSN06($_POST['textSN06']);
        	break; 
        case 'dissasembly06':
        	echo $sistemdetailnota->dissasembly06($_POST['textSN06'],$_POST['nota_id'],$_POST['usr_id'],$_POST['group']); 
        	break; 
        case 'assembly06':
        	echo $sistemdetailnota->assembly06($_POST['textSN06'],$_POST['nota_id'],$_POST['usr_id'],$_POST['group']); 
        	break; 
	
				

    }
?>