<?php
    $action = $_REQUEST['action'];
    $handler->loadModel('group_list_sistem_m');
    $group_list_sistem08 = new group_list_sistem08;

    switch ($action){
	case 'getcmbsistem08':
		$result = $group_list_sistem08->getcmbsistem08($_REQUEST); 
		echo $result;  
			break; 
        case 'read':
            echo $group_list_sistem08->read($_POST['sistemid08'], $_REQUEST);
            break;
    }
?>