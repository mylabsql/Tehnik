<?php
    $action = $_REQUEST['action'];
    $handler->loadModel('list_sistem_m');
    $list_sistem07 = new list_sistem07;

    switch ($action){
	case 'getcmbsistem07':
		$result = $list_sistem07->getcmbsistem07($_REQUEST); 
		echo $result;  
			break; 
        case 'read':
            echo $list_sistem07->read($_POST['sistemid'], $_REQUEST);
            break;
    }
?>