<?php
    $action = $_REQUEST['action'];
    $handler->loadModel('nota_sistem_m');
    $listnotasistem = new Listnotasistem; 

    switch ($action){
	case 'getcmbnmtranssistem05':
		$result = $listnotasistem->getcmbnmtranssistem05($_REQUEST); 
		echo $result;  
			break;
	case 'getcmbEventsistem05':
		$result = $listnotasistem->getcmbEventsistem05($_REQUEST); 
		echo $result;  
			break; 
	case 'getcmbSistem05':
		$result = $listnotasistem->getcmbSistem05($_REQUEST); 
		echo $result;  
			break; 
        case 'getnotasistem05':
            echo $listnotasistem->getnotasistem05($_POST['cmbbulan05'],$_POST['usr_id'],$_POST);
            break;
        case 'getListsistem05':
        	echo $listnotasistem->getListsistem05($_POST['nota_id'],$_POST); 
        	break; 
        case 'getListsistem205':
        	echo $listnotasistem->getListsistem205($_POST['nota_id'],$_POST); 
        	break; 
        case 'create':
            echo $listnotasistem->create($_POST);
            break;
        case 'update':
            echo $listnotasistem->update($_POST);
            break;
        case 'destroy':
            echo $listnotasistem->destroy($_POST['data']);
            break;
        case 'lock':
            echo $listnotasistem->lock($_POST['data']);
            break;  	
        case 'edit':
          echo $listnotasistem->edit($_POST['id'],$_POST); 
          break; 
	
				

    }
?>