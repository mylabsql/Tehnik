<?php
    $action = $_REQUEST['action'];
    $handler->loadModel('tech_event_m');
    $racara = new Tech_event; 

    switch ($action){
	case 'getcmbte_event':
		$result = $racara->getcmbte_event($_REQUEST); 
		echo $result;  
			break;
	case 'getcmbte_eqname_id':
		$result = $racara->getcmbte_eqname_id($_REQUEST); 
		echo $result;  
			break; 		    
        case 'getdokumen':
            echo $racara->getdokumen($_POST);
            break;
        case 'getspek':
        	echo $racara->getspek($_POST['tech_event_id'],$_POST); 
        	break; 
        case 'create':
            echo $racara->create($_POST);
            break;
        case 'update':
            echo $racara->update($_POST);
            break;
        case 'destroy':
            echo $racara->destroy($_POST['data']);
            break;            
        case 'edit':
          echo $racara->edit($_POST['id'],$_POST); 
          break; 
	
				

    }
?>