<?php
 $conf_db = Array();
 $conf_db['db_host'] = 'localhost';
 $conf_db['db_type'] = 'mysqlt';
 $conf_db['db_user'] = 'root';
 $conf_db['db_pwd'] = '';
 $conf_db['db_name'] = 'tehnik';
?>
