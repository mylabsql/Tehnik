valid_script = true;  
group_list_sistem_ajax_url = 'ajax.handler.php?id=' + page;  

var dssistem08 = new Ext.data.JsonStore({
	id:dssistem08,
	url:group_list_sistem_ajax_url,
	totalProperty:'total',
	baseParams:{
		action:'getcmbsistem08'
	},
	sortInfo:{
		field:'sistem',
		direction:'ASC'
	},
	remoteSort:true,
	root:'data',
	fields: [{name:'id'},{ name:'sistem'}]
});

    dssistem08.load({
	params:{
		start:0,
		limit:100
	}
});

var cmbsistem08 = new Ext.form.ComboBox(
{	id:'sistem08',
	anchor:'100%',
	store:dssistem08,
	//name:'id',
	valueField: 'id',
	displayField: 'sistem',
	hiddenValue : 'id',
	hiddenName : 'id',
	fieldLabel: 'Nama sistem',
	emptyText : 'Nama sistem...',
	triggerAction: 'all',
	mode: 'remote',
	editable: true,
	autocomplete: true,
	forceSelection : true,
	pageSize : 100
	      });
cmbsistem08.on("select", function() {
	dynamic_grid_group_list_sistem08.store.baseParams.sistemid08 = cmbsistem08.getValue(); //tampilkan nota dengan parameter bulan yg dipilih
  	dynamic_grid_group_list_sistem08.store.reload();
		});
var dynamic_grid_group_list_sistem08 = new Ext.ux.DynamicGridPanel({
    border:false,
    remoteSort:true, //optional default true
    autoLoadStore:true, //optional default true
    storeUrl:group_list_sistem_ajax_url,
    groupTpl:'[{text} ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})]',
    sortInfo:{field:'nama_id',direction:'ASC'}, //must declaration
    baseParams:{
      action:'read',
      sistemid08:-1
    },
    tbar:['->','Sistem : ',cmbsistem08]
}); 

/**end of form**/

var main_content = {
  id : id_panel,  
  title:n.text,  
  iconCls:n.attributes.iconCls,  
  items : [dynamic_grid_group_list_sistem08],
  listeners:{
    destroy:function(){
      my_win = Ext.getCmp('win-group-list-sistem08');
      if (my_win)
          my_win.destroy(); 
    }
  }
}; 
