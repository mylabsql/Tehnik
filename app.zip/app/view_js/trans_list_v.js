valid_script = true;  
ajax_url_tech_event = 'ajax.handler.php?id=' + page;  
{  // variable
var te_event = new Ext.data.JsonStore({
	id:te_event,
	url:ajax_url_tech_event,
	totalProperty:'total',
	baseParams:{
		action:'getcmbte_event'
	},
	sortInfo:{
		field:'event',
		direction:'ASC'
	},
	remoteSort:true,
	root:'data',
	fields: [{name:'id'},{ name:'event'}]
});

    te_event.load({
	params:{
		start:0,
		limit:100
	}
});

var cmbte_event = new Ext.form.ComboBox(
{	id:'cmbte_event_id',
	url:ajax_url_tech_event,
	name:'event_id',
	anchor:'100%',
	store:te_event,
	//name:'id',
	valueField: 'id',
	displayField: 'event',
	hiddenValue : 'id',
	hiddenName : 'event_id',
    fieldLabel: 'Event',
	emptyText : 'Nama event...',
	triggerAction: 'all',
	mode: 'local',
	editable: true,
	autocomplete: true,
	forceSelection : true
	      });

var te_eqname_id = new Ext.data.JsonStore({
	id:te_eqname_id,
	url:ajax_url_tech_event,
	totalProperty:'total',
	baseParams:{
		action:'getcmbte_eqname_id'
	},
	sortInfo:{
		field:'bagian',
		direction:'ASC'
	},
	remoteSort:true,
	root:'data',
	fields: ['id','bagian']
});


    te_eqname_id.load({
	params:{
		start:0,
		limit:100
	}
});

var cmbte_eqname_id = new Ext.form.ComboBox(
{	id:'eqname_id',
	url:ajax_url_tech_event,
	anchor:'100%',
	store:te_eqname_id,
	//name:'id',
	valueField: 'id',
	displayField: 'bagian',
	hiddenValue : 'id',
	hiddenName : 'eqname_id',
	fieldLabel: 'Equipment',
	emptyText : 'Nama equipment ...',
	triggerAction: 'all',
	mode: 'local',
	editable: false,
	autocomplete: true,
	forceSelection : true,
	      });

}
dokumen_grid_spek = Ext.extend(Ext.grid.EditorGridPanel, {
    title: 'List spesifikasi teknis',
    region: 'center',
    clicksToEdit:1,
    loadMask:true,
    removeData:[],
         
    store: new Ext.data.JsonStore({
      url:ajax_url_tech_event, 
      root:'data', 
      successProperty:'success',
      totalProperty:'total',
      autoLoad: false,
      remoteSort:false, 
      baseParams:{
        action :'getspek', 
        tech_event_id:0
      }, 
      fields:[
      {name:'id', type:'int'},
      {name:'tech_event_id', type:'string'},
      {name:'eqname_id', type:'string'},
      {name:'jumlah', type:'string'},
      {name:'keterangan', type:'string'}
      ]
    }), 
    
    initComponent: function() {
        this.createTbar();
		
        this.columns = [
	        {
	          xtype:'gridcolumn', 
              hidden:true,
              dataIndex:'id', 
              hideable:false
	        },
            {
                xtype: 'gridcolumn',
                dataIndex: 'eqname_id',
                header: 'Nama equipment',
                sortable: true,
                width: 150,
				editor: new Ext.grid.GridEditor(cmbte_eqname_id),
		renderer: function(val){
						index = te_eqname_id.findExact('id',val); 
						if (index != -1){
							rs = te_eqname_id.getAt(index).data; 
							return rs.bagian; 
						}}
            },
            {
                xtype: 'gridcolumn',
                header: 'Jumlah',
                sortable: true,
                dataIndex: 'jumlah',
                editor:{}  F5GFCVBVFVH         m
            },
            {
                xtype: 'gridcolumn',
                header: 'Keterangan',
                sortable: true,
                dataIndex: 'keterangan',
                width: 500,
                editor:{} 
            }
            
        ];
        dokumen_grid_spek.superclass.initComponent.call(this);
    }, 
    createTbar:function(){
      this.tbar = [
      {
        text:'Add Data',
        iconCls:'add-data', 
        scope:this,
        handler:function(){
          rec = new this.store.recordType({});
          this.store.insert(0,rec);
          this.getView().refresh();
          this.startEditing(0,1);                
        }
      },
      	{
        text:'Remove Data',
        iconCls:'table-delete',
        scope:this,
        handler:function(){
          this.stopEditing();
          rec = this.getSelectionModel().getSelectedCell(); 
          if (!rec){
             Ext.example.msg('Peringatan','Seleksi data terlebih dahulu');
          }
          record_data = this.store.getAt(rec[0]); 
          if (record_data.data.id){
            this.removeData.push(record_data.data.id);             
          }
	      this.store.remove(this.store.getAt(rec[0]));
	      this.getView().refresh();
	      if (this.store.getCount() > 0){
	        if (rec[0] > 0)
	          this.getSelectionModel().select(rec[0] - 1, rec[1]);
	        else
	          this.getSelectionModel().select(rec[0], rec[1]);
	      }          
        }
      }
      ]
    },
    getRemoveData:function(){
      return this.removeData; 
    }
});

dokumen_form = Ext.extend(Ext.Window, {
    title: 'Rev no[NOMER REVISI]',
    width: 530,
    height: 459,
    layout: 'border',
    border: false,
    closeAction: 'hide',
    id: 'dokumenWindow',
    modal:true,
    initComponent: function() {
        this.buttons = this.createButton(); 
        this.grid = new dokumen_grid_spek({}); 
        this.items = [
            {
                xtype: 'form',
                region: 'north',
                border: false,
                frame: true,
                url:ajax_url_tech_event, 
                autoHeight: true,
                layoutConfig: {
                    labelSeparator: ' '
                },
                items: [
                    {
                        xtype: 'hidden',
                        fieldLabel: 'id',
                        anchor: '100%',
                        name: 'id'
                    },
                    cmbte_event,
                    {      xtype: 'textfield',                        
                        fieldLabel: 'Rev no',
                        anchor: '100%',
                        width: 200,
                        name: 'rev_no',
                        allowBlank: true
                    },
                    {
                        xtype: 'textarea',                        
                        fieldLabel: 'Keterangan',
                        anchor: '100%',
                        width: 200,
                        name: 'keterangan',
                        allowBlank: true
                    }
                ]
            },this.grid
        ];
        dokumen_form.superclass.initComponent.call(this);
    }, 
    createButton:function(){
      this.botBar = [
      {
        text:'Save',
        scope:this,
        handler:function(){
          this.saveData(); 
        }
      },
      	{
        text:'Close',
        scope:this,
        handler:function(){
          this.hide(); 
        }
      }
      ]; 
      return this.botBar; 
    },
    saveData:function(){
      form = this.get(0).form; 
      if (!form.isValid()){
        Ext.example.msg('Peringatan','Ada data yang tidak valid!'); 
      }
      data =[]; 
      this.grid.store.each(function(r,i){
        data.push(r.data);
      });
      id_data = form.getValues().id;
      action = (id_data)?'update':'create'; 
      form.submit({
        scope:this,
        params:{
          action:action,
          detail:Ext.encode(data),
          remove:this.grid.getRemoveData().join(',')
        }, 
        waitMsg:'Saving Data', 
        success:function(){
          this.hide(); 
          this.onSuccess(action); 
        },
        failure:function(form,action){          
        	switch (action.failureType) {
 
	            case Ext.form.Action.CLIENT_INVALID:
	                Ext.MessageBox.alert('Failure', 'Form fields may not be submitted with invalid values');
	                break;
	            case Ext.form.Action.CONNECT_FAILURE:
	                Ext.MessageBox.alert('Failure', 'Ajax communication failed');
	                break;
	            case Ext.form.Action.SERVER_INVALID:
	                Ext.MessageBox.alert('Failure', action.result.message);
	                break;
	        }  
          
        }
      });
    }, 
    onSuccess:function(action){
      
    },
    onAddData:function(){
      this.get(0).form.reset(); 
      this.grid.store.baseParams.tech_event_id = 0; /* acara */
      this.grid.store.reload(); 
    },
    reloadGrid:function(tech_event_id){ /*acara_id*/
      this.grid.store.baseParams.tech_event_id = tech_event_id;/*acara_id*/
      this.grid.store.reload(); 
    }    
});

win_dokumen_form = new dokumen_form({
   onSuccess:function(action){
    grid_dokumen.store.reload(); 
    grid_act.store.reload();
    
   }
}); 

/*----end window---- */
//Form utama => List Jadwal Acara & List Activity crew 
{
var grid_dokumen = new Ext.ux.DynamicGroupingGrid({
    title:'Rev no[NOMER REVISI]', 
    region:'center', 
    border:false,
 //   groupField:'event_id', // select the field for grouping  
    groupTpl:'[{text} ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})]',
    remoteSort:true, //optional default true
    autoLoadStore:true, //optional default true
    storeUrl:ajax_url_tech_event,
    sortInfo:{field:'id',direction:'ASC'}, //must declaration
    baseParams:{
      action:'getdokumen',
    }, 
    tbarDisable:{  //if not declaration default is true
      add:!ROLE.ADD_DATA,
      edit:!ROLE.EDIT_DATA,
      remove:!ROLE.REMOVE_DATA
    },
    onAddData:function(bt){
      win_dokumen_form.setTitle('Penambahan standar spesifikasi teknis event');
      win_dokumen_form.show(bt.id);    
      win_dokumen_form.onAddData(); 
   },
    onEditData:function(bt,rec){
      win_dokumen_form.setTitle('Ubah standar spesifikasi teknis event');
      win_dokumen_form.show(bt.id); 
      win_dokumen_form.get(0).getForm().load({
          waitMsg:'Loading Data..',
          params:{action:'edit',id:rec.data.id}
      }); 
      win_dokumen_form.reloadGrid(rec.data.id); 
    },   
    onRemoveData:function(bt,rec){
      data = []; 
      Ext.each(rec,function(r){
        data.push(r.data.id); 
      }); 
      Ext.Ajax.request({
        url: ajax_url_tech_event, 
        params:{
          action:'destroy',
          data:data.join(",")
        },
        success:function(res){
          result = Ext.decode(res.responseText); 
          if (result.success){
	          this.store.reload(); 
	          grid_rec.store.reload();            
          }else{
            Ext.MessageBox.alert('Error',result.message);
          }

        },
        scope:this
      });       
    }    
}); 

grid_dokumen.getSelectionModel().on('rowselect',function(sel,index,rec){
  grid_act.store.baseParams.tech_event_id = rec.data.id;
  grid_act.store.reload(); 
}); 

var grid_act = new Ext.ux.DynamicGridPanel({
  title :'List spesifikasi teknis', 
  border:false,
  region:'south', 
  height:270,
  collapsible:true,  
  remoteSort:true,
  storeUrl:ajax_url_tech_event, 
  sortInfo:{field:'id', direction:'ASC'}, 
  baseParams:{
    action:'getspek', 
    tech_event_id:0
  }
}); 
}
var main_content = {
  id : id_panel,  
  title:n.text,  
  iconCls:n.attributes.iconCls,  
  layout:'border', //split for 2 column layout
  items : [grid_dokumen,grid_act],
  listeners:{
    destroy:function(){
      my_win = Ext.getCmp('dokumenWindow');
      if (my_win)
          my_win.destroy(); 
    }
  }
}; 