valid_script = true;  
list_sistem_ajax_url = 'ajax.handler.php?id=' + page;  

var dssistem07 = new Ext.data.JsonStore({
	id:dssistem07,
	url:list_sistem_ajax_url,
	totalProperty:'total',
	baseParams:{
		action:'getcmbsistem07'
	},
	sortInfo:{
		field:'sistem',
		direction:'ASC'
	},
	remoteSort:true,
	root:'data',
	fields: [{name:'id'},{ name:'sistem'}]
});

    dssistem07.load({
	params:{
		start:0,
		limit:100
	}
});

var cmbsistem07 = new Ext.form.ComboBox(
{	id:'sistem07',
	anchor:'100%',
	store:dssistem07,
	//name:'id',
	valueField: 'id',
	displayField: 'sistem',
	hiddenValue : 'id',
	hiddenName : 'id',
	fieldLabel: 'Nama sistem',
	emptyText : 'Nama sistem...',
	triggerAction: 'all',
	mode: 'remote',
	editable: true,
	autocomplete: true,
	forceSelection : true,
	pageSize : 100
	      });
cmbsistem07.on("select", function() {
	dynamic_grid_list_sistem07.store.baseParams.sistemid = cmbsistem07.getValue(); //tampilkan nota dengan parameter bulan yg dipilih
  	dynamic_grid_list_sistem07.store.reload();
		});
var dynamic_grid_list_sistem07 = new Ext.ux.DynamicGridPanel({
    border:false,
    remoteSort:true, //optional default true
    autoLoadStore:true, //optional default true
    storeUrl:list_sistem_ajax_url,
    groupTpl:'[{text} ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})]',
    sortInfo:{field:'nama_id',direction:'ASC'}, //must declaration
    baseParams:{
      action:'read',
      sistemid:-1
    },
    tbar:['->','Sistem : ',cmbsistem07]
}); 



win_list_sistem07 = new Ext.Window({
	id:'win-list-sistem07',
	iconCls:n.attributes.iconCls,
        layoutConfig: {
    	padding:'5',
    	pack:'center',
    	align:'middle'
	},
  layout:'border',
  height:350,
  closeAction:'hide',
  closable:true,
  width:550,
  modal: true,
  plain:true,
  frame:true,
  items:[],
  buttons:[
  {
    text:'Save',
    handler:function()
    {	if(!Ext.getCmp('win_list_sistem07').getForm().isValid()){
        Ext.example.msg('Peringatan','Ada data yang kosong'); 
      }
      
      id_data = Ext.getCmp('win_list_sistem07').getForm().getValues().id; 
      action = (id_data?'update':'create'); 
      Ext.getCmp('win_list_sistem07').getForm().submit({
          params:{action:action,
	  usr_id:userid},
          waitMsg : 'Saving Data',
          success:function(){
            win_list_sistem07.hide();
            Ext.example.msg('Simpan','Data telah disimpan'); 
            dynamic_grid_list_sistem07.store.reload(); 
          },
        failure:function(form,action){          
	         switch (action.failureType) {
	            case Ext.form.Action.CLIENT_INVALID:
	                Ext.MessageBox.alert('Failure', 'Form fields may not be submitted with invalid values');
	                break;
	            case Ext.form.Action.CONNECT_FAILURE:
	                Ext.MessageBox.alert('Failure', 'Ajax communication failed');
	                break;
	            case Ext.form.Action.SERVER_INVALID:
	                Ext.MessageBox.alert('Failure', action.result.message);
	                break;
	        }  
          
        }
      }); 
      
    }
  },{
    text:'Close',
    handler:function(){
      win_list_sistem07.hide(); 
    }
  }
  ]
}); 

/**end of form**/


var main_content = {
  id : id_panel,  
  title:n.text,  
  iconCls:n.attributes.iconCls,  
  items : [dynamic_grid_list_sistem07],
  listeners:{
    destroy:function(){
      my_win = Ext.getCmp('win-list-sistem07');
      if (my_win)
          my_win.destroy(); 
    }
  }
}; 
